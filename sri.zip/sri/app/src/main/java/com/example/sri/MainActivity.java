package com.example.sri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sri.R;

import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {

    EditText name, phone, res_name;
    Button send;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        name = findViewById(R.id.name);
        phone = findViewById(R.id.phone);


        res_name = findViewById(R.id.res_name);


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Name, Phone, Res_name;

                Name = name.getText().toString();
                Phone = phone.getText().toString();
                Res_name = res_name.getText().toString();



                if (name.equals("")) ;
                {
                    Toast.makeText(MainActivity.this, "name is blank", Toast.LENGTH_SHORT).show();
                }
                if (phone.equals("")) ;
                {
                    Toast.makeText(MainActivity.this, "name is blank", Toast.LENGTH_SHORT).show();
                }
                if (res_name.equals("")) ;
                {
                    Toast.makeText(MainActivity.this, "name is blank", Toast.LENGTH_SHORT).show();
                }


            }


        });

    }
}
